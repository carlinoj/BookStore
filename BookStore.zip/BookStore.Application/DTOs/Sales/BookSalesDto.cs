﻿namespace BookStore.Application.DTOs.Sales;

public class BookSalesDto
{
    public Guid LivroId { get; set; }
 
    public int Quantidade { get; set; }
}